﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Management;

namespace Session1_Tankaeva
{
    static class Program
    {
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Autoriz());
            Application.Run(new scrDispatcher());
            //Application.Run(new UserSchedules());
            //Application.Run(new scrAdm("j.doe@amonic.com"));
            //Application.Run(new scrUser("k.omar@amonic.com"));
            //Application.Run(new scrMngr("m@.com"));
            //Application.Run(new SchdlsChanges());


            //Проверка в базе данных прошел ли месяц с последней записи - если в базе пусто или прошел месяц - пишем новые данные
            int id = 1;
            DataA DataA = new DataA();
            DataTable dt_sys = DataA.Select("SELECT * FROM System");
            if (dt_sys.Rows.Count > 0)
            {
                DataTable dt_sys2 = DataA.Select("SELECT MAX(ID) FROM System");
                id = Convert.ToInt32(dt_sys2.Rows[0][0]);
                dt_sys2 = DataA.Select("SELECT * FROM System Where ID = " + id);
                if ((DateTime.Now - Convert.ToDateTime(dt_sys2.Rows[0][1])).TotalDays > 30)
                {
                    id += 1;
                    WriteSystemDt();
                }
            }
            else
            {
                WriteSystemDt();
            }

          //запись данных
            void WriteSystemDt()
            {
                string name = "", OS = "", Arc = "", FPM = "", TVMS = "";
                ObjectQuery wql2 = new ObjectQuery("SELECT * FROM Win32_ComputerSystem");
                ManagementObjectSearcher searcher2 = new ManagementObjectSearcher(wql2);
                ManagementObjectCollection results2 = searcher2.Get();
                foreach (ManagementObject result in results2)
                {

                    name = result["Caption"].ToString();
                }
                ObjectQuery wql = new ObjectQuery("SELECT * FROM Win32_OperatingSystem");
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(wql);
                ManagementObjectCollection results = searcher.Get();

                foreach (ManagementObject result in results)
                {
                    TVMS = result["TotalVisibleMemorySize"].ToString() + " KB";
                    FPM = result["FreePhysicalMemory"].ToString() + " KB";
                    OS = result["Name"].ToString().Split()[1] + result["Name"].ToString().Split()[2];
                    Arc = result["OSArchitecture"].ToString();
                }

                DataTable dt_sysIns = DataA.Select("Insert INTO System VALUES(" + id + ", '" + DateTime.Now +
                    "', '" + name + "','" + OS + "','" + Arc + "','" + FPM + "','" + TVMS + "')");
            }
        }
       
    }

    

    //Подключение к базе данных один sql
    public class DataT
    {
        public DataTable Select(string selectSQL)
        {
            DataTable dataTable = new DataTable("dataBase");
            
           
            SqlConnection sqlConnection = new SqlConnection("server=LAPTOP-HIOJQFOH\\SQLEXPRESS;" +
               "Trusted_Connection=Yes;DataBase=Amonic;Max Pool Size=10000;");
            sqlConnection.Open();
            SqlCommand sqlCommand = sqlConnection.CreateCommand();
            sqlCommand.CommandText = selectSQL;
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dataTable);
            return dataTable;
        }
    }

    //Поключение к базе данных два access
    public class DataA
    {
        public DataTable Select(string selectSQL)
        {
            DataTable dt = new DataTable();
            try { 
                OleDbConnection con = new OleDbConnection(@"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = C:\Users\jay\Desktop\Авиа проект\Amonic\Session1_Tankaeva\bin\Debug\dbo.mdb");
                OleDbDataAdapter ada = new OleDbDataAdapter(selectSQL, con);
               
                ada.Fill(dt);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            //MessageBox.Show(selectSQL);
           
           
            return dt;
            
        }
    }
}
