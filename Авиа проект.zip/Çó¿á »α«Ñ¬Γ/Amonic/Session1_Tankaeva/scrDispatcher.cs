﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Session1_Tankaeva
{
    public partial class scrDispatcher : Form
    {
        public scrDispatcher()
        {
            InitializeComponent();
        }

        private void ScrDispatcher_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "amonicDataSet.Routes". При необходимости она может быть перемещена или удалена.
            this.routesTableAdapter.Fill(this.amonicDataSet.Routes);
            tableFill();
           
        }

        void tableFill()
        {
            DataT DataT = new DataT();
            DataTable dt_airports = DataT.Select("SELECT * FROM [dbo].[Airports]");
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                //название аэропортов в таблице
                if (dt_airports.Rows.Count > 0)
                {
                    for (int j = 0; j < dt_airports.Rows.Count; j++)
                    {

                        if (dataGridView1.Rows[i].Cells[1].Value.ToString() == dt_airports.Rows[j][0].ToString())
                        {
                            dataGridView1.Rows[i].Cells[2].Value = dt_airports.Rows[j][2].ToString();
                        }
                        if (dataGridView1.Rows[i].Cells[3].Value.ToString() == dt_airports.Rows[j][0].ToString())
                        {
                            dataGridView1.Rows[i].Cells[4].Value = dt_airports.Rows[j][2].ToString();
                        }

                    }
                }
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            newRoute nR = new newRoute();
            nR.ShowDialog();
            this.routesTableAdapter.Fill(this.amonicDataSet.Routes);
            tableFill();
        }
    }
}
