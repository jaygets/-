﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Session1_Tankaeva
{
    public partial class newRoute : Form
    {
        public newRoute()
        {
            InitializeComponent();
        }

        //только цифры на ввод
        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }

        private void TextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            DataT DataT = new DataT();
            if (textBox1.Text != "" && textBox2.Text != "" &&
                comboBox1.SelectedIndex != -1 && comboBox2.SelectedIndex != -1 && comboBox1.SelectedIndex != comboBox2.SelectedIndex)
            {

                DataTable dt_airpot1 = DataT.Select("SELECT ID FROM [dbo].[Airports] Where IATACode = '" + comboBox1.Text + "'");
                DataTable dt_airpot2 = DataT.Select("SELECT ID FROM [dbo].[Airports] Where IATACode = '" + comboBox2.Text + "'");

                int airport1 = Convert.ToInt32(dt_airpot1.Rows[0][0]);
                int airport2 = Convert.ToInt32(dt_airpot2.Rows[0][0]);

                try
                {
                    DataTable dt_rout = DataT.Select("Insert INTO [dbo].[Routes] VALUES('"+  airport1+ "','" + airport2 +
                        "','" + Convert.ToInt32(textBox1.Text) + "','" + Convert.ToInt32(textBox2.Text) + "' )");
                    MessageBox.Show("Маршрут успешно добавлен", "Info",
                       MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    MessageBox.Show("Заполните все поля коректно!", "Внимание!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            else
            {
                MessageBox.Show("Заполните все поля корректно!", "Внимание!",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void NewRoute_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "amonicDataSet.Airports". При необходимости она может быть перемещена или удалена.
            this.airportsTableAdapter.Fill(this.amonicDataSet.Airports);

        }
    }
}
