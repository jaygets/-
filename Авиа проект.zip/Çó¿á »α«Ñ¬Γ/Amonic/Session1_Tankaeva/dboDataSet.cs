﻿namespace Session1_Tankaeva
{
}
namespace Session1_Tankaeva
{


    public partial class dboDataSet
    {
    }
}
namespace Session1_Tankaeva {
    
    
    public partial class dboDataSet {
    }
}
