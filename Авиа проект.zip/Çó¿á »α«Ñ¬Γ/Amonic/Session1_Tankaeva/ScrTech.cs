﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Session1_Tankaeva
{
    public partial class ScrTech : Form
    {
        public ScrTech()
        {
            InitializeComponent();
        }

        private void ScrTech_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dboDataSet.Tracking". При необходимости она может быть перемещена или удалена.
            this.trackingTableAdapter.Fill(this.dboDataSet.Tracking);

           

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                try
                {
                    DataA DataA = new DataA();
                    DataTable dt_user = DataA.Select("SELECT * FROM Users WHERE ID =" + Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value));
                    if (dt_user.Rows.Count > 0)
                    {
                        dataGridView1.Rows[i].Cells[1].Value = dt_user.Rows[0][2].ToString();
                    }

                  }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
               
                //Если пользователь вылетел из системы
                if (dataGridView1.Rows[i].Cells[5].Value.ToString() != "")
                {
                    dataGridView1.Rows[i].Cells[4].Value = "";
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(255, 46, 46);
                }
            }

               

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
