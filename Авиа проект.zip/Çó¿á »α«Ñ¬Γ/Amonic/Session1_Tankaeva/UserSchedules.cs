﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Session1_Tankaeva
{
    public partial class UserSchedules : Form
    {
        public UserSchedules()
        {
            InitializeComponent();
            setData();
        }

        //преобразование данных из бд для таблицы
        void setData()
        {
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {

                DataT DataT = new DataT();
                DataTable dt_airports = DataT.Select("SELECT * FROM [dbo].[Airports]");
                if (dt_airports.Rows.Count > 0)
                {
                    for (int j = 0; j < dt_airports.Rows.Count; j++)
                    {
                        if (dataGridView1.Rows[i].Cells[3].Value != null)
                        {
                            if (dataGridView1.Rows[i].Cells[3].Value.ToString() == dt_airports.Rows[j][0].ToString())
                            {
                                dataGridView1.Rows[i].Cells[4].Value = dt_airports.Rows[j][2].ToString();
                            }
                        }
                        if (dataGridView1.Rows[i].Cells[5].Value != null)
                        {
                            if (dataGridView1.Rows[i].Cells[5].Value.ToString() == dt_airports.Rows[j][0].ToString())
                            {
                                dataGridView1.Rows[i].Cells[6].Value = dt_airports.Rows[j][2].ToString();
                            }
                        }
                    }

                }
                dataGridView1.Rows[i].Cells[10].Value = Math.Round(Convert.ToDouble(dataGridView1.Rows[i].Cells[10].Value), 0);
                dataGridView1.Rows[i].Cells[11].Value = Math.Round(Convert.ToDouble(dataGridView1.Rows[i].Cells[10].Value) * 1.35, 0);
                dataGridView1.Rows[i].Cells[12].Value = Math.Round(Convert.ToDouble(dataGridView1.Rows[i].Cells[11].Value) * 1.3, 0);
                if (Convert.ToBoolean(dataGridView1.Rows[i].Cells[7].Value) == false)
                {
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(192, 0, 0);
                }

            }

        }

        private void UserSchedules_Load(object sender, EventArgs e)
        {
            this.schedules1TableAdapter.Fill(this.amonicDataSet.Schedules1);
            setData();
        }

        //закрытие
        private void Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
