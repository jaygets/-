﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Session1_Tankaeva
{
    public partial class NoLogOut : Form
    {
        string ident;
        string reason = "Re:";
        public NoLogOut(string id, string logIn)
        {
            InitializeComponent();
            label1.Text = label1.Text + logIn;
            ident = id;
            //вносим в причину часть с re
            DataA DataA = new DataA();
            DataTable dt_track = DataA.Select("UPDATE Tracking SET Reason = '"
                + reason + "', LogOut = '" + DateTime.Now + "'" +
             " WHERE ID =" + Convert.ToInt32(ident));
        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            DataA DataA = new DataA();
            
            if (rbSoft.Checked == true)
            {
                reason = "Software crush;";
            }
            if (rbSystem.Checked == true)
            {
                reason += "System crush;";
            }
            reason += textBox1.Text;

            DataTable dt_track = DataA.Select("UPDATE Tracking SET Reason = '"
                + reason +"', LogOut = '" + DateTime.Now + "'" +
             " WHERE ID =" + Convert.ToInt32(ident));

            MessageBox.Show("Причина успешно обновлена!", "Info",
                       MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void NoLogOut_Load(object sender, EventArgs e)
        {

        }
    }
}
